﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{

    public partial class Form1 : Form
    {
        private TreeNode selectedNode = null;//定义一个全局变量selectedNode为空
        public Form1()
        {
            InitializeComponent();


        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            this.selectedNode = this.treeView1.SelectedNode;//把选中节点的值赋予全局变量selectNode
        }

        private void treeView1_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            textBox2.Text = e.Node.Text;//点击treeview节点，数值在textbox展示
        }

        private void Form1_Click(object sender, EventArgs e)
        {
            this.Activate();
            this.Focus();
            this.textBox2.Text = null;//点击窗体清除文本框内的值
            textBox2.Enabled = false;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBox1.Enabled = false;//不可与用户交互
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            treeView1.ExpandAll();//节点全展开
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            textBox2.Enabled = true;//使textbox2可交互（即可输出）
            if (!string.IsNullOrWhiteSpace(textBox2.Text))//忽略文本框没有字符或只有空格和null值
            {
                var cur = treeView1.SelectedNode;//定义一个未知变量cur赋给当前选中节点
                if (cur != null)//如果cur不等于空（即选中节点）
                    cur.Nodes.Add(textBox2.Text);//添加父节点

                else
                    treeView1.Nodes.Add(textBox2.Text);//添加子节点
                MessageBox.Show("添加成功");
            }
            return;
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            textBox2.Enabled = true;//使textbox2可交互（即可输出）
            if (this.selectedNode != null)
            {
                this.textBox2.Text = this.selectedNode.Text;
                this.treeView1.Focus();//给与焦点
            }
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            textBox2.Enabled = false;//使textbox2不可交互（即禁止输出）
            if (this.selectedNode != null)
            {
                this.selectedNode.Text = this.textBox2.Text;
                this.treeView1.Focus();
            }
            MessageBox.Show("保存成功!");
        }

        private void toolStripButton4_Click(object sender, EventArgs e)
        {

            if (treeView1.SelectedNode == null)//如果没有选中节点，即选中节点为null.
            {
                MessageBox.Show("请选择删除节点!");
                return;
            }
            MessageBox.Show("已删除!");
            treeView1.SelectedNode.Remove();//按钮删除节点

        }
    }
}
